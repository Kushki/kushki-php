<?php

namespace kushki\lib;

class KushkiEnvironment {
    const TESTING_TOKEN = 'https://uat.aurusinc.com/kushki/api/v1';
    const TESTING = 'https://api-uat.kushkipagos.com/v1';
    const STAGING = 'https://api-stg.kushkipagos.com/v1';
    const PRODUCTION = 'https://api.kushkipagos.com/v1';
}