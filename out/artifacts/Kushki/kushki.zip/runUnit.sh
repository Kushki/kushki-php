#!/usr/bin/env bash

phpunit --configuration phpunit.xml --testsuite unit