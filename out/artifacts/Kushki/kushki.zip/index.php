<?php

use kushki\lib\Kushki;
use kushki\lib\KushkiCurrencies;
use kushki\lib\KushkiLanguages;
use kushki\lib\KushkiConstant;

include_once("autoload.php");

$merchantId = "10000001408518323354818001";
$idioma = KushkiLanguages::ES;
$moneda = KushkiCurrencies::USD;
$monto = 10.00;
$kushki = new Kushki($merchantId, $idioma, $moneda);

$cardParams = array(
    KushkiConstant::PARAMETER_CARD_NAME => "John Doe",
    KushkiConstant::PARAMETER_CARD_NUMBER => "4111111111111111",
    KushkiConstant::PARAMETER_CARD_EXP_MONTH => "12",
    KushkiConstant::PARAMETER_CARD_EXP_YEAR => "20",
    KushkiConstant::PARAMETER_CARD_CVC => "123",
);

$tokenTransaction = $kushki->requestToken($cardParams);
if ($tokenTransaction->isSuccessful()) {
    $token = $tokenTransaction->getToken();
    echo 'Token transaction: '.$tokenTransaction->getResponseText() . '<br/>';
    echo 'Token: ' . $token;

    $chargeTransaction = $kushki->charge($token, 10.0);
    if ($chargeTransaction->isSuccessful()) {
        echo '<br/><br/>Charge transaction: ' . $chargeTransaction->getResponseText() . '<br/>';
        echo "Número de ticket: " . $chargeTransaction->getTicketNumber();
        echo "<br/>Monto aprobado: " . $chargeTransaction->getBody()->approved_amount;

        $ticket = $chargeTransaction->getTicketNumber();
        $token4refundTransaction = $kushki->requestToken($cardParams);
        $token4refund = $token4refundTransaction->getToken();
        $refundTransaction = $kushki->refundCharge($token4refund, $ticket, 10.0);
        if($refundTransaction->isSuccessful()) {
            echo '<br/><br/>Refund transaction: ' . $chargeTransaction->getResponseText() . '<br/>';
            echo "Número de ticket: " . $chargeTransaction->getTicketNumber();
            echo "<br/>Monto aprobado: " . $chargeTransaction->getBody()->approved_amount;
        }
    }
} else {
    echo 'Ha ocurrido un error ' . $tokenTransaction->getCode() . ': ' . $tokenTransaction->getResponseText();
}