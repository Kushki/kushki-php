<?php

namespace kushki\lib;

class KushkiLanguages {
    const
        __default = 'es',
        ES = 'es',
        EN = 'en';
}

class KushkiCurrencies {
    const
        __default = 'USD',
        USD = 'USD';
}

?>
