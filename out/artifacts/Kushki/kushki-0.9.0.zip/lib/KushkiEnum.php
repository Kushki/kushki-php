<?php

namespace kushki\lib;

class KushkiLanguage {
    const
        __default = 'es',
        ES = 'es',
        EN = 'en';
}

class KushkiCurrency {
    const
        __default = 'USD',
        USD = 'USD';
}

?>
